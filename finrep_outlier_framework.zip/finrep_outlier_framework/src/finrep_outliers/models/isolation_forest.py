"""Isolation Forest wrapper using scikit-learn when available."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import OutlierDetector


class IsolationForestDetector(OutlierDetector):
    """
    Isolation Forest benchmark.

    Requires scikit-learn.

    Higher score = more anomalous.
    """

    method_name = "IsolationForest"

    def __init__(self, *, n_estimators: int = 200, random_state: int = 0, contamination: str | float = "auto"):
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.contamination = contamination

    def fit(self, X: pd.DataFrame) -> "IsolationForestDetector":
        try:
            from sklearn.ensemble import IsolationForest
        except ImportError as exc:
            raise ImportError(
                "IsolationForestDetector requires scikit-learn. "
                "Install with: pip install scikit-learn"
            ) from exc

        self.columns_ = list(X.columns)
        self.model_ = IsolationForest(
            n_estimators=self.n_estimators,
            random_state=self.random_state,
            contamination=self.contamination,
        )
        self.model_.fit(X.astype(float).to_numpy())
        return self

    def score_samples(self, X: pd.DataFrame) -> np.ndarray:
        self._check_is_fitted()
        X_arr = X.loc[:, self.columns_].astype(float).to_numpy()

        # sklearn: lower score_samples = more abnormal.
        # We invert so that higher = more anomalous.
        return -self.model_.score_samples(X_arr)

    def _check_is_fitted(self) -> None:
        if not hasattr(self, "model_"):
            raise RuntimeError("IsolationForestDetector is not fitted.")
