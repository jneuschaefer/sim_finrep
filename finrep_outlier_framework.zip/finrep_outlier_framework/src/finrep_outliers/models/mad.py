"""Robust univariate baseline based on median absolute deviation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import OutlierDetector


class MADDetector(OutlierDetector):
    """
    MAD-based multivariate score.

    For each feature j:

        z_ij = |x_ij - median_j| / (1.4826 * MAD_j)

    Row score options:
        max: catches single-cell data-quality errors
        mean: catches broad moderate deviations
        l2: catches distributed deviations
    """

    method_name = "MAD"

    def __init__(self, aggregation: str = "max", eps: float = 1e-12):
        if aggregation not in {"max", "mean", "l2"}:
            raise ValueError("aggregation must be one of {'max', 'mean', 'l2'}.")
        self.aggregation = aggregation
        self.eps = eps

    def fit(self, X: pd.DataFrame) -> "MADDetector":
        self.columns_ = list(X.columns)
        X_num = X.astype(float)
        self.median_ = X_num.median(axis=0, skipna=True)
        abs_dev = (X_num - self.median_).abs()
        mad = abs_dev.median(axis=0, skipna=True)
        scale = 1.4826 * mad
        scale = scale.replace(0, np.nan).fillna(1.0)
        self.scale_ = scale.where(scale.abs() > self.eps, 1.0)
        return self

    def score_samples(self, X: pd.DataFrame) -> np.ndarray:
        self._check_is_fitted()
        X_num = X.loc[:, self.columns_].astype(float)
        X_imp = X_num.fillna(self.median_)
        z = ((X_imp - self.median_) / self.scale_).abs()

        if self.aggregation == "max":
            scores = z.max(axis=1)
        elif self.aggregation == "mean":
            scores = z.mean(axis=1)
        else:
            scores = np.sqrt((z ** 2).sum(axis=1))

        return np.asarray(scores, dtype=float)

    def _check_is_fitted(self) -> None:
        if not hasattr(self, "median_"):
            raise RuntimeError("MADDetector is not fitted.")
