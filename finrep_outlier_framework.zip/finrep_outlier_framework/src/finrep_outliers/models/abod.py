"""Approximate ABOD-style angular outlier score."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import OutlierDetector


class ApproxABODDetector(OutlierDetector):
    """
    Approximate Angle-Based Outlier Detection.

    Classical ABOD assigns low angular variance to outliers.
    Here the returned outlier score is:

        score = - angular_variance

    so higher = more anomalous.

    This implementation is intentionally simple and suitable for smaller thesis
    experiments or subsampled benchmarks.
    """

    method_name = "ApproxABOD"

    def __init__(self, n_reference: int | None = 100, random_state: int = 0, eps: float = 1e-12):
        self.n_reference = n_reference
        self.random_state = random_state
        self.eps = eps

    def fit(self, X: pd.DataFrame) -> "ApproxABODDetector":
        self.columns_ = list(X.columns)
        X_arr = X.astype(float).to_numpy()
        rng = np.random.default_rng(self.random_state)

        if self.n_reference is not None and len(X_arr) > self.n_reference:
            idx = rng.choice(len(X_arr), size=self.n_reference, replace=False)
            self.reference_ = X_arr[idx]
        else:
            self.reference_ = X_arr

        return self

    def score_samples(self, X: pd.DataFrame) -> np.ndarray:
        self._check_is_fitted()
        X_arr = X.loc[:, self.columns_].astype(float).to_numpy()
        scores = np.empty(X_arr.shape[0], dtype=float)

        for i, x in enumerate(X_arr):
            vectors = self.reference_ - x
            norms = np.linalg.norm(vectors, axis=1)
            valid = norms > self.eps
            vectors = vectors[valid]
            norms = norms[valid]

            if len(vectors) < 3:
                scores[i] = 0.0
                continue

            unit = vectors / norms[:, None]
            cosines = unit @ unit.T
            upper = cosines[np.triu_indices_from(cosines, k=1)]
            angular_variance = np.var(upper)
            scores[i] = -angular_variance

        return scores

    def _check_is_fitted(self) -> None:
        if not hasattr(self, "reference_"):
            raise RuntimeError("ApproxABODDetector is not fitted.")
