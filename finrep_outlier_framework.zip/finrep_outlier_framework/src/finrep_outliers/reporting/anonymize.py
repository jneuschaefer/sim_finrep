"""Confidentiality-preserving exports for real FINREP results."""

from __future__ import annotations

import hashlib

import pandas as pd


def stable_anonymous_id(value: object, *, salt: str) -> str:
    """
    Create stable pseudonymous id from a sensitive identifier.

    Keep the salt private and outside version control.
    """
    h = hashlib.sha256(f"{salt}:{value}".encode("utf-8")).hexdigest()
    return f"anon_{h[:12]}"


def anonymize_ranking(
    ranking: pd.DataFrame,
    *,
    id_column: str = "gebernummer",
    salt: str,
    drop_raw_id: bool = True,
    score_percentile: bool = True,
) -> pd.DataFrame:
    """
    Replace bank identifiers and optionally convert raw scores to percentiles.

    This is intended for thesis-safe result exports.
    """
    out = ranking.copy()
    out["anonymous_bank_id"] = out[id_column].map(lambda x: stable_anonymous_id(x, salt=salt))

    if score_percentile and "score" in out.columns:
        out["score_percentile"] = out["score"].rank(pct=True)
        out = out.drop(columns=["score"])

    if drop_raw_id:
        out = out.drop(columns=[id_column])

    safe_first = ["anonymous_bank_id"]
    other_cols = [c for c in out.columns if c not in safe_first]
    return out[safe_first + other_cols]
