"""Reusable scoring pipelines."""

from __future__ import annotations

import pandas as pd

from finrep_outliers.models.base import OutlierDetector, make_ranking
from finrep_outliers.preprocessing.scaling import RobustPreprocessor


def fit_score_with_preprocessing(
    X: pd.DataFrame,
    metadata: pd.DataFrame,
    detector: OutlierDetector,
    *,
    feature_space: str,
    robust_preprocess: bool = True,
) -> pd.DataFrame:
    """
    Fit a detector and return a standardized ranking table.

    Missing values should be handled before most detectors. By default, this
    applies median imputation and IQR scaling.
    """
    if robust_preprocess:
        preprocessor = RobustPreprocessor()
        X_model = preprocessor.fit_transform(X)
    else:
        X_model = X.copy()

    scores = detector.fit_score(X_model)
    return make_ranking(
        scores,
        metadata=metadata,
        method=detector.method_name,
        feature_space=feature_space,
    )
