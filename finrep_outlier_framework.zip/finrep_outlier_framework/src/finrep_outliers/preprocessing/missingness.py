"""Missingness summaries and simple threshold-based filtering."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class MissingnessReport:
    column_missing_rate: pd.Series
    row_missing_rate: pd.Series


def summarize_missingness(X: pd.DataFrame) -> MissingnessReport:
    """Return column-wise and row-wise missingness rates."""
    return MissingnessReport(
        column_missing_rate=X.isna().mean(axis=0).sort_values(ascending=False),
        row_missing_rate=X.isna().mean(axis=1),
    )


def filter_by_missingness(
    X: pd.DataFrame,
    *,
    max_column_missing_rate: float = 0.5,
    max_row_missing_rate: float = 0.5,
) -> tuple[pd.DataFrame, pd.Index, pd.Index]:
    """
    Filter columns and rows by missingness thresholds.

    Returns
    -------
    X_filtered:
        Filtered feature matrix.
    kept_rows:
        Original row index kept.
    kept_columns:
        Original column index kept.
    """
    if not 0 <= max_column_missing_rate <= 1:
        raise ValueError("max_column_missing_rate must be between 0 and 1.")
    if not 0 <= max_row_missing_rate <= 1:
        raise ValueError("max_row_missing_rate must be between 0 and 1.")

    kept_columns = X.columns[X.isna().mean(axis=0) <= max_column_missing_rate]
    X_col = X.loc[:, kept_columns]

    kept_rows = X_col.index[X_col.isna().mean(axis=1) <= max_row_missing_rate]
    X_filtered = X_col.loc[kept_rows].copy()

    return X_filtered, kept_rows, kept_columns
