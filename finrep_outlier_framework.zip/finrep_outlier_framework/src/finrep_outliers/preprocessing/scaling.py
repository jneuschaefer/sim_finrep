"""Robust imputation and scaling for outlier-detection feature matrices."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class RobustPreprocessor:
    """
    Median-impute and robust-scale features.

    Scaling is:

        z = (x - median) / IQR

    with fallback scale 1.0 for constant or nearly constant features.
    """

    eps: float = 1e-12

    def fit(self, X: pd.DataFrame) -> "RobustPreprocessor":
        self.columns_ = list(X.columns)
        self.median_ = X.median(axis=0, skipna=True)
        q75 = X.quantile(0.75, axis=0)
        q25 = X.quantile(0.25, axis=0)
        iqr = q75 - q25
        iqr = iqr.replace(0, np.nan).fillna(1.0)
        iqr = iqr.where(iqr.abs() > self.eps, 1.0)
        self.scale_ = iqr
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        self._check_is_fitted()
        X_aligned = X.loc[:, self.columns_].copy()
        X_imputed = X_aligned.fillna(self.median_)
        X_scaled = (X_imputed - self.median_) / self.scale_
        return X_scaled.replace([np.inf, -np.inf], np.nan).fillna(0.0)

    def fit_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return self.fit(X).transform(X)

    def _check_is_fitted(self) -> None:
        if not hasattr(self, "columns_"):
            raise RuntimeError("RobustPreprocessor is not fitted.")
