"""
Feature-matrix construction for FINREP outlier detection.

Central rule:
    gebernummer and date are keys, not model features.

Peer feature space:
    R_{i,t} = X_{i,t} / A_{i,t}

Temporal feature space:
    Delta R_{i,t} = R_{i,t} - R_{i,t-1}

where A_{i,t} is total assets, by default F0101_0380_0010.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

import numpy as np
import pandas as pd


DEFAULT_TOTAL_ASSETS_COLUMN = "F0101_0380_0010"
DEFAULT_ID_COLUMN = "gebernummer"
DEFAULT_DATE_COLUMN = "date"


@dataclass(frozen=True)
class FeatureMatrix:
    """Container for model features and non-model metadata."""
    X: pd.DataFrame
    metadata: pd.DataFrame
    feature_columns: list[str]


class FeatureMatrixError(ValueError):
    """Raised when feature-matrix construction fails due to invalid input."""


def _as_list(columns: Iterable[str]) -> list[str]:
    return list(columns)


def validate_required_columns(df: pd.DataFrame, required_columns: Iterable[str]) -> None:
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise FeatureMatrixError(f"Missing required columns: {missing}")


def validate_value_columns(
    value_columns: Iterable[str],
    *,
    id_column: str,
    date_column: str,
    total_assets_column: str,
) -> list[str]:
    value_columns = _as_list(value_columns)

    forbidden = {id_column, date_column}
    illegal = [col for col in value_columns if col in forbidden]
    if illegal:
        raise FeatureMatrixError(
            f"Identifier/date columns must not be model features: {illegal}"
        )

    if total_assets_column in value_columns:
        # A/A is a constant and should not be a model feature.
        value_columns = [col for col in value_columns if col != total_assets_column]

    if not value_columns:
        raise FeatureMatrixError("No usable value columns remain after validation.")

    return value_columns


def prepare_dates(df: pd.DataFrame, date_column: str) -> pd.DataFrame:
    out = df.copy()
    out[date_column] = pd.to_datetime(out[date_column])
    return out


def _safe_ratio_frame(
    df: pd.DataFrame,
    value_columns: list[str],
    total_assets_column: str,
) -> pd.DataFrame:
    total_assets = pd.to_numeric(df[total_assets_column], errors="coerce")

    invalid_assets = total_assets.isna() | (total_assets == 0)
    ratios = df[value_columns].apply(pd.to_numeric, errors="coerce").div(total_assets, axis=0)

    # Rows with invalid total assets cannot produce meaningful normalized ratios.
    ratios.loc[invalid_assets, :] = np.nan

    ratios = ratios.replace([np.inf, -np.inf], np.nan)
    ratios.columns = [f"ratio__{col}" for col in value_columns]
    return ratios


def compute_total_asset_ratios(
    df: pd.DataFrame,
    value_columns: Iterable[str],
    *,
    total_assets_column: str = DEFAULT_TOTAL_ASSETS_COLUMN,
    id_column: str = DEFAULT_ID_COLUMN,
    date_column: str = DEFAULT_DATE_COLUMN,
) -> FeatureMatrix:
    """
    Compute total-assets-normalized FINREP ratios.

    Returns
    -------
    FeatureMatrix
        X contains only ratio features.
        metadata contains id, date, and total assets.
    """
    value_columns = validate_value_columns(
        value_columns,
        id_column=id_column,
        date_column=date_column,
        total_assets_column=total_assets_column,
    )

    validate_required_columns(
        df,
        [id_column, date_column, total_assets_column, *value_columns],
    )

    work = prepare_dates(df, date_column)
    X = _safe_ratio_frame(work, value_columns, total_assets_column)

    metadata = work[[id_column, date_column, total_assets_column]].copy()
    metadata = metadata.reset_index(drop=True)
    X = X.reset_index(drop=True)

    return FeatureMatrix(
        X=X,
        metadata=metadata,
        feature_columns=list(X.columns),
    )


def build_peer_ratio_matrix(
    df: pd.DataFrame,
    quarter,
    value_columns: Iterable[str],
    *,
    total_assets_column: str = DEFAULT_TOTAL_ASSETS_COLUMN,
    id_column: str = DEFAULT_ID_COLUMN,
    date_column: str = DEFAULT_DATE_COLUMN,
    peer_group_column: Optional[str] = None,
    peer_group_value: Optional[object] = None,
) -> FeatureMatrix:
    """
    Build the peer-outlier feature matrix for one quarter.

    The model matrix contains only total-assets-normalized ratios for that quarter.
    The id/date/group fields remain in metadata only.
    """
    validate_required_columns(df, [id_column, date_column, total_assets_column])
    work = prepare_dates(df, date_column)
    quarter = pd.to_datetime(quarter)

    mask = work[date_column] == quarter

    if peer_group_column is not None:
        validate_required_columns(work, [peer_group_column])
        if peer_group_value is not None:
            mask = mask & (work[peer_group_column] == peer_group_value)

    selected = work.loc[mask].copy()

    fm = compute_total_asset_ratios(
        selected,
        value_columns,
        total_assets_column=total_assets_column,
        id_column=id_column,
        date_column=date_column,
    )

    if peer_group_column is not None:
        fm.metadata[peer_group_column] = selected[peer_group_column].reset_index(drop=True)

    return fm


def build_quarterly_delta_matrix(
    df: pd.DataFrame,
    quarter,
    value_columns: Iterable[str],
    *,
    total_assets_column: str = DEFAULT_TOTAL_ASSETS_COLUMN,
    id_column: str = DEFAULT_ID_COLUMN,
    date_column: str = DEFAULT_DATE_COLUMN,
    peer_group_column: Optional[str] = None,
    peer_group_value: Optional[object] = None,
    require_previous_quarter: bool = True,
) -> FeatureMatrix:
    """
    Build the temporal-outlier feature matrix for one quarter.

    Computes true ratio changes:

        Delta R_{i,t} = R_{i,t} - R_{i,t-1}

    The previous observation is determined within each `gebernummer` time series.
    """
    validate_required_columns(df, [id_column, date_column, total_assets_column])
    work = prepare_dates(df, date_column)
    quarter = pd.to_datetime(quarter)

    if peer_group_column is not None:
        validate_required_columns(work, [peer_group_column])
        if peer_group_value is not None:
            work = work.loc[work[peer_group_column] == peer_group_value].copy()

    ratios = compute_total_asset_ratios(
        work,
        value_columns,
        total_assets_column=total_assets_column,
        id_column=id_column,
        date_column=date_column,
    )

    panel = pd.concat([ratios.metadata, ratios.X], axis=1)
    if peer_group_column is not None and peer_group_column in work.columns:
        panel[peer_group_column] = work[peer_group_column].reset_index(drop=True)

    panel = panel.sort_values([id_column, date_column]).reset_index(drop=True)

    ratio_cols = ratios.feature_columns
    previous_ratios = panel.groupby(id_column, sort=False)[ratio_cols].shift(1)
    previous_dates = panel.groupby(id_column, sort=False)[date_column].shift(1)

    delta = panel[ratio_cols] - previous_ratios
    delta.columns = [col.replace("ratio__", "delta_ratio__", 1) for col in ratio_cols]

    target_mask = panel[date_column] == quarter

    if require_previous_quarter:
        expected_previous = quarter - pd.offsets.QuarterEnd(1)
        target_mask = target_mask & (previous_dates == expected_previous)

    selected_delta = delta.loc[target_mask].reset_index(drop=True)

    metadata_columns = [id_column, date_column, total_assets_column]
    if peer_group_column is not None and peer_group_column in panel.columns:
        metadata_columns.append(peer_group_column)

    selected_metadata = panel.loc[target_mask, metadata_columns].reset_index(drop=True)
    selected_metadata["previous_date"] = previous_dates.loc[target_mask].reset_index(drop=True)

    return FeatureMatrix(
        X=selected_delta,
        metadata=selected_metadata,
        feature_columns=list(selected_delta.columns),
    )
