"""Evaluation metrics for simulation experiments."""

from __future__ import annotations

import numpy as np
import pandas as pd


def make_binary_labels(
    metadata: pd.DataFrame,
    injected_labels: pd.DataFrame,
    *,
    outlier_type: str | None = None,
    id_column: str = "gebernummer",
    date_column: str = "date",
) -> np.ndarray:
    """
    Align injected simulation labels to a result metadata table.

    Returns 1 if the row is an injected anomaly, 0 otherwise.
    """
    if injected_labels.empty:
        return np.zeros(len(metadata), dtype=int)

    labels = injected_labels.copy()
    labels[date_column] = pd.to_datetime(labels[date_column])

    if outlier_type is not None:
        labels = labels.loc[labels["outlier_type"] == outlier_type]

    key_set = set(zip(labels[id_column], labels[date_column]))

    meta = metadata.copy()
    meta[date_column] = pd.to_datetime(meta[date_column])
    return np.array(
        [(gid, date) in key_set for gid, date in zip(meta[id_column], meta[date_column])],
        dtype=int,
    )


def precision_at_k(y_true: np.ndarray, scores: np.ndarray, k: int) -> float:
    """Precision among top-k scores."""
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)
    k = min(k, len(scores))
    if k <= 0:
        return np.nan
    top = np.argsort(scores)[::-1][:k]
    return float(y_true[top].mean())


def recall_at_k(y_true: np.ndarray, scores: np.ndarray, k: int) -> float:
    """Recall among top-k scores."""
    y_true = np.asarray(y_true).astype(int)
    positives = y_true.sum()
    if positives == 0:
        return np.nan
    k = min(k, len(scores))
    top = np.argsort(scores)[::-1][:k]
    return float(y_true[top].sum() / positives)


def average_rank_of_anomalies(y_true: np.ndarray, scores: np.ndarray) -> float:
    """Average descending rank of true anomalies."""
    y_true = np.asarray(y_true).astype(int)
    scores = np.asarray(scores).astype(float)
    if y_true.sum() == 0:
        return np.nan

    order = np.argsort(scores)[::-1]
    ranks = np.empty_like(order)
    ranks[order] = np.arange(1, len(scores) + 1)
    return float(ranks[y_true == 1].mean())


def evaluate_topk(
    y_true: np.ndarray,
    scores: np.ndarray,
    *,
    ks: list[int] = [5, 10, 20],
) -> pd.DataFrame:
    """Return a small top-k metric table."""
    rows = []
    for k in ks:
        rows.append(
            {
                "k": k,
                "precision_at_k": precision_at_k(y_true, scores, k),
                "recall_at_k": recall_at_k(y_true, scores, k),
            }
        )
    rows.append({"k": "avg_rank", "precision_at_k": np.nan, "recall_at_k": average_rank_of_anomalies(y_true, scores)})
    return pd.DataFrame(rows)
