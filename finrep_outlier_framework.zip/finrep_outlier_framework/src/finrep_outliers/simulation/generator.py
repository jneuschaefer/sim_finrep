"""
Synthetic FINREP-style panel generator.

The generator creates:
    - total assets A_i,t
    - normalized reporting ratios R_i,t
    - raw values X_i,t = A_i,t * R_i,t
    - optional missingness
    - injected peer, temporal, and data-quality outliers

This gives known ground truth for method evaluation.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class SimulationConfig:
    n_banks: int = 120
    n_quarters: int = 8
    n_features: int = 40
    n_factors: int = 4
    start_date: str = "2022-03-31"
    random_state: int = 0
    missing_rate: float = 0.03
    peer_outlier_fraction: float = 0.04
    temporal_outlier_fraction: float = 0.04
    data_quality_outlier_fraction: float = 0.02
    peer_outlier_strength: float = 5.0
    temporal_outlier_strength: float = 5.0
    data_quality_multiplier: float = 25.0
    total_assets_column: str = "F0101_0380_0010"
    id_column: str = "gebernummer"
    date_column: str = "date"


@dataclass(frozen=True)
class SimulationResult:
    data: pd.DataFrame
    value_columns: list[str]
    labels: pd.DataFrame


def make_quarter_ends(start_date: str, n_quarters: int) -> pd.DatetimeIndex:
    """Return quarter-end dates."""
    start = pd.to_datetime(start_date)
    return pd.date_range(start=start, periods=n_quarters, freq="QE")


def simulate_finrep_panel(config: SimulationConfig = SimulationConfig()) -> SimulationResult:
    rng = np.random.default_rng(config.random_state)

    bank_ids = [f"BANK_{i:04d}" for i in range(config.n_banks)]
    dates = make_quarter_ends(config.start_date, config.n_quarters)
    value_columns = [f"F_SIM_{j:04d}" for j in range(config.n_features)]

    # Bank size distribution: log-normal total assets.
    bank_size = rng.normal(loc=12.0, scale=1.0, size=config.n_banks)
    quarter_growth = rng.normal(loc=0.01, scale=0.03, size=(config.n_banks, config.n_quarters))
    log_assets = bank_size[:, None] + np.cumsum(quarter_growth, axis=1)
    total_assets = np.exp(log_assets)

    # Latent factor ratio structure.
    bank_factors = rng.normal(size=(config.n_banks, config.n_factors))
    time_factors = rng.normal(scale=0.35, size=(config.n_quarters, config.n_factors))
    loadings = rng.normal(scale=0.10, size=(config.n_factors, config.n_features))
    baseline = rng.normal(loc=0.05, scale=0.03, size=config.n_features)

    ratios = np.empty((config.n_banks, config.n_quarters, config.n_features))
    for t in range(config.n_quarters):
        latent = bank_factors + time_factors[t]
        ratios[:, t, :] = baseline + latent @ loadings + rng.normal(
            scale=0.02,
            size=(config.n_banks, config.n_features),
        )

    # FINREP positions may be negative, but this clips extreme synthetic values.
    ratios = np.clip(ratios, -1.0, 1.5)
    raw_values = ratios * total_assets[:, :, None]

    labels = []
    injected_cells = set()

    def add_label(bank_idx: int, quarter_idx: int, outlier_type: str, feature: str | None = None):
        labels.append(
            {
                config.id_column: bank_ids[bank_idx],
                config.date_column: dates[quarter_idx],
                "outlier_type": outlier_type,
                "feature": feature,
            }
        )

    n_peer = max(1, int(config.peer_outlier_fraction * config.n_banks * config.n_quarters))
    n_temporal = max(1, int(config.temporal_outlier_fraction * config.n_banks * max(config.n_quarters - 1, 1)))
    n_quality = max(1, int(config.data_quality_outlier_fraction * config.n_banks * config.n_quarters))

    # Peer outliers: whole ratio-vector displacement in one quarter.
    for _ in range(n_peer):
        i = rng.integers(config.n_banks)
        t = rng.integers(config.n_quarters)
        direction = rng.normal(size=config.n_features)
        direction /= np.linalg.norm(direction) + 1e-12
        shift = config.peer_outlier_strength * 0.10 * direction
        ratios[i, t, :] += shift
        raw_values[i, t, :] = ratios[i, t, :] * total_assets[i, t]
        add_label(i, t, "peer")

    # Temporal outliers: sudden jump relative to previous quarter.
    for _ in range(n_temporal):
        i = rng.integers(config.n_banks)
        t = rng.integers(1, config.n_quarters)
        direction = rng.normal(size=config.n_features)
        direction /= np.linalg.norm(direction) + 1e-12
        jump = config.temporal_outlier_strength * 0.10 * direction
        ratios[i, t, :] = ratios[i, t - 1, :] + jump
        raw_values[i, t, :] = ratios[i, t, :] * total_assets[i, t]
        add_label(i, t, "temporal")

    # Data-quality errors: isolated absurd cells.
    for _ in range(n_quality):
        i = rng.integers(config.n_banks)
        t = rng.integers(config.n_quarters)
        j = rng.integers(config.n_features)
        raw_values[i, t, j] *= config.data_quality_multiplier
        injected_cells.add((i, t, j))
        add_label(i, t, "data_quality", value_columns[j])

    # Missingness in raw reporting positions.
    missing_mask = rng.random(size=raw_values.shape) < config.missing_rate
    raw_values[missing_mask] = np.nan

    rows = []
    for i, bank in enumerate(bank_ids):
        peer_group = "large" if total_assets[i].mean() > np.median(total_assets.mean(axis=1)) else "small"
        for t, date in enumerate(dates):
            row = {
                config.id_column: bank,
                config.date_column: date,
                "peer_group": peer_group,
                config.total_assets_column: total_assets[i, t],
            }
            row.update({col: raw_values[i, t, j] for j, col in enumerate(value_columns)})
            rows.append(row)

    data = pd.DataFrame(rows)
    labels_df = pd.DataFrame(labels).drop_duplicates(
        subset=[config.id_column, config.date_column, "outlier_type", "feature"]
    ).reset_index(drop=True)

    return SimulationResult(data=data, value_columns=value_columns, labels=labels_df)
