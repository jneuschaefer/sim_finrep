# FINREP Outlier Detection Framework

Programming foundation for a master's thesis on outlier/anomaly detection in high-dimensional FINREP supervisory data.

The framework separates:

- **keys / metadata**: `gebernummer`, `date`, optional peer group variables
- **model features**: total-assets-normalized reporting ratios or quarterly ratio changes

## Main feature spaces

Peer outliers, one quarter at a time:

```text
R_i,t = X_i,t / A_i,t
```

Temporal outliers:

```text
Delta R_i,t = R_i,t - R_i,t-1
```

where `A_i,t` is total assets, by default `F0101_0380_0010`.

## Install

```bash
pip install -e ".[dev]"
```

Optional for Isolation Forest:

```bash
pip install scikit-learn
```

Optional for AE/VAE later:

```bash
pip install torch
```

## Run tests

```bash
pytest -q
```

## Run demo simulation

```bash
python scripts/run_simulation_demo.py
```

This creates example result tables in `outputs/tables/`.

## Important confidentiality rule

Do not commit raw FINREP data or bank-identifying result exports.

For real-data exports, use the anonymization tools in `src/finrep_outliers/reporting/anonymize.py`.
