from pathlib import Path

import pandas as pd

from finrep_outliers.evaluation.metrics import evaluate_topk, make_binary_labels
from finrep_outliers.models.mad import MADDetector
from finrep_outliers.models.pca import PCAReconstructionDetector
from finrep_outliers.pipeline import fit_score_with_preprocessing
from finrep_outliers.preprocessing.feature_matrix import (
    build_peer_ratio_matrix,
    build_quarterly_delta_matrix,
)
from finrep_outliers.simulation.generator import SimulationConfig, simulate_finrep_panel


def main():
    output_dir = Path("outputs/tables")
    output_dir.mkdir(parents=True, exist_ok=True)

    config = SimulationConfig(
        n_banks=120,
        n_quarters=8,
        n_features=40,
        random_state=42,
    )
    sim = simulate_finrep_panel(config)

    quarter = pd.to_datetime(config.start_date) + pd.DateOffset(months=3 * (config.n_quarters - 1))

    peer_fm = build_peer_ratio_matrix(
        sim.data,
        quarter=quarter,
        value_columns=sim.value_columns,
        peer_group_column="peer_group",
    )

    temporal_fm = build_quarterly_delta_matrix(
        sim.data,
        quarter=quarter,
        value_columns=sim.value_columns,
        peer_group_column="peer_group",
    )

    detectors = [
        MADDetector(aggregation="max"),
        PCAReconstructionDetector(variance_explained=0.8),
    ]

    all_rankings = []
    all_metrics = []

    for feature_space, fm, outlier_type in [
        ("peer_ratios", peer_fm, "peer"),
        ("temporal_deltas", temporal_fm, "temporal"),
    ]:
        for detector in detectors:
            ranking = fit_score_with_preprocessing(
                fm.X,
                fm.metadata,
                detector,
                feature_space=feature_space,
            )
            all_rankings.append(ranking)

            y_true = make_binary_labels(
                ranking,
                sim.labels,
                outlier_type=outlier_type,
            )
            metric_table = evaluate_topk(y_true, ranking["score"].to_numpy(), ks=[5, 10, 20])
            metric_table["method"] = detector.method_name
            metric_table["feature_space"] = feature_space
            all_metrics.append(metric_table)

    rankings = pd.concat(all_rankings, ignore_index=True)
    metrics = pd.concat(all_metrics, ignore_index=True)

    rankings.to_csv(output_dir / "simulation_rankings.csv", index=False)
    metrics.to_csv(output_dir / "simulation_metrics.csv", index=False)

    print("Wrote:")
    print(f"  {output_dir / 'simulation_rankings.csv'}")
    print(f"  {output_dir / 'simulation_metrics.csv'}")
    print()
    print(metrics)


if __name__ == "__main__":
    main()
