import pandas as pd
import pytest

from finrep_outliers.preprocessing.feature_matrix import (
    FeatureMatrixError,
    build_peer_ratio_matrix,
    build_quarterly_delta_matrix,
    compute_total_asset_ratios,
)


def toy_finrep_panel():
    return pd.DataFrame(
        {
            "gebernummer": ["A", "B", "A", "B", "C"],
            "date": [
                "2024-03-31",
                "2024-03-31",
                "2024-06-30",
                "2024-06-30",
                "2024-06-30",
            ],
            "peer_group": ["large", "small", "large", "small", "large"],
            "F0101_0380_0010": [100.0, 200.0, 110.0, 250.0, 300.0],
            "loans": [50.0, 80.0, 66.0, 100.0, 180.0],
            "deposits": [70.0, 160.0, 77.0, 125.0, 150.0],
        }
    )


def test_compute_total_asset_ratios_excludes_keys_and_total_assets():
    df = toy_finrep_panel()

    fm = compute_total_asset_ratios(
        df,
        value_columns=["loans", "deposits", "F0101_0380_0010"],
    )

    assert "gebernummer" not in fm.X.columns
    assert "date" not in fm.X.columns
    assert "F0101_0380_0010" not in fm.X.columns

    assert list(fm.X.columns) == ["ratio__loans", "ratio__deposits"]
    assert fm.X.loc[0, "ratio__loans"] == pytest.approx(0.5)
    assert fm.X.loc[0, "ratio__deposits"] == pytest.approx(0.7)


def test_identifier_columns_are_rejected_as_value_columns():
    df = toy_finrep_panel()

    with pytest.raises(FeatureMatrixError):
        compute_total_asset_ratios(df, value_columns=["gebernummer", "loans"])

    with pytest.raises(FeatureMatrixError):
        compute_total_asset_ratios(df, value_columns=["date", "loans"])


def test_peer_ratio_matrix_selects_one_quarter():
    df = toy_finrep_panel()

    fm = build_peer_ratio_matrix(
        df,
        quarter="2024-06-30",
        value_columns=["loans", "deposits"],
    )

    assert len(fm.X) == 3
    assert set(fm.metadata["gebernummer"]) == {"A", "B", "C"}
    assert all(fm.metadata["date"] == pd.Timestamp("2024-06-30"))

    row_a = fm.metadata.index[fm.metadata["gebernummer"] == "A"][0]
    assert fm.X.loc[row_a, "ratio__loans"] == pytest.approx(66.0 / 110.0)


def test_peer_ratio_matrix_can_filter_peer_group():
    df = toy_finrep_panel()

    fm = build_peer_ratio_matrix(
        df,
        quarter="2024-06-30",
        value_columns=["loans", "deposits"],
        peer_group_column="peer_group",
        peer_group_value="large",
    )

    assert set(fm.metadata["gebernummer"]) == {"A", "C"}
    assert "peer_group" in fm.metadata.columns
    assert set(fm.metadata["peer_group"]) == {"large"}


def test_quarterly_delta_matrix_computes_true_ratio_differences():
    df = toy_finrep_panel()

    fm = build_quarterly_delta_matrix(
        df,
        quarter="2024-06-30",
        value_columns=["loans", "deposits"],
    )

    assert set(fm.metadata["gebernummer"]) == {"A", "B"}

    row_a = fm.metadata.index[fm.metadata["gebernummer"] == "A"][0]
    row_b = fm.metadata.index[fm.metadata["gebernummer"] == "B"][0]

    assert fm.X.loc[row_a, "delta_ratio__loans"] == pytest.approx(0.1)
    assert fm.X.loc[row_b, "delta_ratio__deposits"] == pytest.approx(-0.3)

    assert all(fm.metadata["previous_date"] == pd.Timestamp("2024-03-31"))


def test_invalid_total_assets_produce_missing_ratios_not_inf():
    df = pd.DataFrame(
        {
            "gebernummer": ["A", "B"],
            "date": ["2024-03-31", "2024-03-31"],
            "F0101_0380_0010": [0.0, 100.0],
            "loans": [50.0, 25.0],
        }
    )

    fm = compute_total_asset_ratios(df, value_columns=["loans"])

    assert pd.isna(fm.X.loc[0, "ratio__loans"])
    assert fm.X.loc[1, "ratio__loans"] == pytest.approx(0.25)
