import numpy as np
import pandas as pd

from finrep_outliers.evaluation.metrics import make_binary_labels, precision_at_k
from finrep_outliers.models.mad import MADDetector
from finrep_outliers.models.pca import PCAReconstructionDetector
from finrep_outliers.pipeline import fit_score_with_preprocessing
from finrep_outliers.preprocessing.feature_matrix import build_peer_ratio_matrix
from finrep_outliers.simulation.generator import SimulationConfig, simulate_finrep_panel


def test_simulator_returns_panel_and_labels():
    config = SimulationConfig(
        n_banks=20,
        n_quarters=4,
        n_features=8,
        random_state=123,
    )
    sim = simulate_finrep_panel(config)

    assert sim.data.shape[0] == 20 * 4
    assert len(sim.value_columns) == 8
    assert not sim.labels.empty
    assert {"peer", "temporal", "data_quality"}.issubset(set(sim.labels["outlier_type"]))


def test_mad_detector_scores_obvious_outlier_highest():
    X = pd.DataFrame(
        {
            "x1": [0, 0.1, -0.1, 0.05, 10.0],
            "x2": [0, 0.1, -0.1, 0.05, 0.0],
        }
    )

    detector = MADDetector(aggregation="max")
    scores = detector.fit_score(X)

    assert int(np.argmax(scores)) == 4


def test_pca_detector_produces_scores():
    X = pd.DataFrame(np.random.default_rng(0).normal(size=(30, 5)))
    detector = PCAReconstructionDetector(n_components=2)
    scores = detector.fit_score(X)

    assert scores.shape == (30,)
    assert np.all(scores >= 0)


def test_pipeline_outputs_ranking_with_metadata():
    config = SimulationConfig(
        n_banks=30,
        n_quarters=4,
        n_features=10,
        random_state=123,
    )
    sim = simulate_finrep_panel(config)
    quarter = pd.to_datetime("2022-12-31")

    fm = build_peer_ratio_matrix(
        sim.data,
        quarter=quarter,
        value_columns=sim.value_columns,
        peer_group_column="peer_group",
    )

    ranking = fit_score_with_preprocessing(
        fm.X,
        fm.metadata,
        MADDetector(),
        feature_space="peer_ratios",
    )

    assert len(ranking) == len(fm.X)
    assert "gebernummer" in ranking.columns
    assert "score" in ranking.columns
    assert "rank" in ranking.columns
    assert ranking["rank"].min() == 1

    y_true = make_binary_labels(ranking, sim.labels, outlier_type="peer")
    p5 = precision_at_k(y_true, ranking["score"].to_numpy(), k=5)
    assert 0.0 <= p5 <= 1.0
